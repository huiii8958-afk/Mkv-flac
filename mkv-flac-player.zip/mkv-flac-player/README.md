# MKV FLAC Player — Variant 2 (bit-perfect USB DAC)

Кастомный Android-плеер для MKV + FLAC, который **обходит весь Android-аудиостек** и шлёт PCM напрямую в USB-ЦАП через Linux usbdevfs isochronous transfers.

## ⚠️ Состояние: первая итерация, ожидайте багов

Это **первая компиляция** кода, написанного без возможности тестировать на реальном железе. Очень вероятно, что:
- Не соберётся с первого раза (опечатки, версии API)
- Соберётся, но крашнется при запуске
- Не получит exclusive access к ЦАПу (Android держит его сам)
- Получит доступ, но звук будет тишина / треск / искажения

Это **нормально** для такого проекта. Шли мне ошибки/логи — буду чинить итерациями.

## Архитектура

```
ExoPlayer (декодирует MKV → PCM)
        ↓
MediaCodecAudioRenderer
        ↓
UsbAudioSink (наш кастомный AudioSink, заменяет DefaultAudioSink)
        ↓
NativeUsbAudio (Kotlin JNI обёртка)
        ↓
UsbAudioEngine (C++ через NDK)
        ↓
Linux usbdevfs ioctl (USBDEVFS_SUBMITURB)
        ↓
USB-ЦАП (DT03)
```

**Минуем:** Android AudioFlinger, mixer, ресемплер, audio HAL, USB audio HAL.

## Структура

```
mkv-flac-player/
├── .github/workflows/build.yml          # автосборка APK
├── settings.gradle.kts
├── build.gradle.kts
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
└── app/
    ├── build.gradle.kts                  # NDK + Compose + Media3
    └── src/main/
        ├── AndroidManifest.xml
        ├── cpp/                          # нативная часть (C++17)
        │   ├── CMakeLists.txt
        │   ├── uac2_descriptors.h/.cpp   # парсер USB Audio Class 2.0
        │   ├── usb_audio_engine.h/.cpp   # ядро: isochronous transfers
        │   └── jni_bridge.cpp            # JNI экспорты
        ├── kotlin/com/example/mkvflacplayer/
        │   ├── MainActivity.kt
        │   ├── PlayerScreen.kt           # UI + ExoPlayer wiring
        │   ├── audio/
        │   │   ├── NativeUsbAudio.kt     # обёртка JNI
        │   │   └── UsbAudioSink.kt       # кастомный AudioSink для ExoPlayer
        │   └── usb/
        │       └── UsbDacManager.kt      # USB Host API + permissions
        └── res/
            ├── values/strings.xml
            ├── values/themes.xml
            └── xml/usb_device_filter.xml
```

## Сборка с телефона через GitHub Actions

У тебя нет компьютера — собираем в облаке GitHub. Раз настроишь, дальше каждый коммит будет сам собирать APK.

### Шаг 1. Создай аккаунт на GitHub

[github.com](https://github.com) → Sign up. Бесплатно. С телефона работает.

### Шаг 2. Создай новый репозиторий

GitHub → правый верх → "+" → "New repository":
- Name: `mkv-flac-player` (любое)
- **Public** (для бесплатных GitHub Actions)
- Без README, .gitignore, license — мы свои зальём
- Create repository

### Шаг 3. Залей файлы проекта

На странице пустого репозитория → "uploading an existing file" (или "Add file" → "Upload files").

**Из ZIP-архива, который дал я:**
1. Распакуй ZIP в файловом менеджере на телефоне (большинство умеют).
2. В GitHub-веб-интерфейсе нажми "choose your files" и выбери **все файлы из распакованной папки**, **сохраняя структуру путей**.

⚠️ Веб-интерфейс GitHub поддерживает drag&drop **папок целиком** — это самый простой способ. Если не работает — заливай по подпапкам.

Альтернатива: установи приложение **Working Copy** или **GitHub Mobile** — там удобнее работать с репозиториями.

После заливки коммить (зелёная кнопка "Commit changes").

### Шаг 4. Запусти сборку

После коммита GitHub Actions **автоматически** запустит сборку. Чтобы посмотреть:
- Открой репозиторий → вкладка **Actions**.
- Увидишь jobs со значками ⏳ или ✅.
- Кликни в job → раскрой шаги.

Сборка занимает 8–15 минут (медленнее обычного из-за NDK + libusb).

### Шаг 5. Скачай APK

Когда job станет ✅ зелёным:
- В нём внизу есть секция **Artifacts**.
- Скачай `mkv-flac-player-debug-apk` (ZIP-архив).
- Распакуй → внутри `app-debug.apk`.

### Шаг 6. Установи APK

Открой APK на телефоне → "Установить". Android спросит разрешение «Установка из неизвестных источников» — разреши для браузера, которым скачал.

### Шаг 7. Запусти и протестируй

1. Воткни DT03 в Type-C.
2. Открой "MKV FLAC Player".
3. Android спросит разрешение на USB-устройство → разреши.
4. Должен появиться статус «Bit-perfect готов: letshuoer Dt03 Dac&Amp» (или ошибка — шли мне).
5. Нажми «Открыть MKV / FLAC» → выбери файл.
6. Воспроизведение начнётся.

## Если что-то не работает

### Сборка упала (❌ в Actions)

1. Открой failed job → раскрой все шаги.
2. Скопируй секцию с ошибкой (обычно последние ~50 строк до красной).
3. Пришли мне в чат — я починю.

### APK установился, но крашнется

Нужны logcat-логи. На телефоне:
1. Установи **Logcat Reader** (бесплатное приложение из Play Store).
2. Запусти MKV FLAC Player, лови краш.
3. В Logcat Reader открой лог приложения и скопируй последние ~30 строк до краша.

Ищи строки с тэгами `UsbAudioEngine`, `UsbAudioJni`, `UsbAudioSink`, `UsbDacManager`, `UacDesc`.

### Статус «CLAIM_FAILED»

Это самый ожидаемый failure mode: Android держит USB-ЦАП в системном audio HAL и не отдаёт его нам.

Что попробовать:
1. Настройки → Подключённые устройства → отключить «USB Audio Routing» (если есть).
2. Настройки → Для разработчиков → включить «Disable USB audio routing».
3. Воткнуть ЦАП **после** запуска приложения.

Если не помогает — шли мне результат, посмотрим, можно ли вырвать устройство более грубо.

### Звука нет / тишина

Проверь в Logcat:
- Какой выбран `audioEndpoint` (должен быть OUT, т.е. без бита 0x80)
- Какой `syncType` (для DT03 ожидаемо ASYNC=1)
- Установился ли sample rate (`Sample rate ... установлен`)
- `urbsCompleted` растёт?

### Треск / искажения

Скорее всего проблема с feedback endpoint (DT03 — async DAC, требует чтения feedback). В первой версии feedback не реализован — я его добавлю в следующей итерации после твоих логов.

## Что НЕ реализовано в этой версии (TODO)

- ❌ Чтение feedback endpoint (для точной синхронизации async ЦАПа)
- ❌ Парсинг Clock Source ID из AC interface (сейчас захардкожен 0x09 → 0x10)
- ❌ DSD (только PCM)
- ❌ A/V sync (видео может уплывать от звука)
- ❌ Восстановление при отключении/переподключении DAC

Это всё планируется в следующих итерациях.

## Технологии

- **Kotlin 1.9.22** + Jetpack Compose
- **AndroidX Media3 1.3.1** (ExoPlayer)
- **C++17** через Android NDK 26
- **CMake 3.22.1**
- **minSdk 26** (Android 8), **targetSdk 34**
- Linux **usbdevfs** напрямую (без libusb — для упрощения сборки)
