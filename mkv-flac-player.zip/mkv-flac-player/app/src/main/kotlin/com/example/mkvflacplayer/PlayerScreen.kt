package com.example.mkvflacplayer

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.Usb
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioRendererEventListener
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.MediaCodecAudioRenderer
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector
import androidx.media3.exoplayer.Renderer
import androidx.media3.ui.PlayerView
import com.example.mkvflacplayer.audio.NativeUsbAudio
import com.example.mkvflacplayer.audio.UsbAudioSink
import com.example.mkvflacplayer.usb.UsbDacManager

sealed class UsbState {
    data object NotConnected : UsbState()
    data class Connected(val name: String) : UsbState()
    data object PermissionDenied : UsbState()
    data class Ready(val name: String) : UsbState()
    data class Error(val message: String) : UsbState()
}

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen() {
    val context = LocalContext.current
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var fileName by remember { mutableStateOf<String?>(null) }
    var usbState by remember { mutableStateOf<UsbState>(UsbState.NotConnected) }
    var statsText by remember { mutableStateOf("—") }

    val dacManager = remember { UsbDacManager(context) }
    val nativeEngine = remember { NativeUsbAudio() }
    val usbSink = remember { UsbAudioSink(nativeEngine) }
    var openedDac by remember { mutableStateOf<UsbDacManager.OpenedDac?>(null) }

    // Создаём ExoPlayer с кастомным RenderersFactory
    val exoPlayer = remember {
        val renderersFactory = object : DefaultRenderersFactory(context) {
            override fun buildAudioRenderers(
                context: Context,
                extensionRendererMode: Int,
                mediaCodecSelector: MediaCodecSelector,
                enableDecoderFallback: Boolean,
                audioSink: AudioSink,
                eventHandler: Handler,
                eventListener: AudioRendererEventListener,
                out: ArrayList<Renderer>
            ) {
                // Подменяем стандартный AudioSink на наш USB-bypass sink
                out.add(
                    MediaCodecAudioRenderer(
                        context, mediaCodecSelector, enableDecoderFallback,
                        eventHandler, eventListener, usbSink
                    )
                )
            }
        }.apply {
            setEnableDecoderFallback(true)
        }

        ExoPlayer.Builder(context)
            .setRenderersFactory(renderersFactory)
            .build()
            .apply { playWhenReady = true }
    }

    // Поиск/подключение USB-ЦАПа
    LaunchedEffect(Unit) {
        val device = dacManager.findUacDevice()
        if (device == null) {
            usbState = UsbState.NotConnected
            return@LaunchedEffect
        }
        usbState = UsbState.Connected(device.productName ?: "USB DAC")
        dacManager.requestPermission(device) { granted ->
            if (!granted) {
                usbState = UsbState.PermissionDenied
                return@requestPermission
            }
            val opened = dacManager.openDevice(device)
            if (opened == null) {
                usbState = UsbState.Error("Не удалось открыть устройство")
                return@requestPermission
            }
            openedDac = opened
            val rc = nativeEngine.init(opened.fileDescriptor, opened.configDescriptor)
            if (rc != NativeUsbAudio.OK) {
                usbState = UsbState.Error("init: ${NativeUsbAudio.errorName(rc)}")
                opened.connection.close()
                openedDac = null
                return@requestPermission
            }
            usbState = UsbState.Ready(device.productName ?: "USB DAC")
        }
    }

    // Периодическое обновление статистики
    LaunchedEffect(usbState) {
        if (usbState is UsbState.Ready) {
            while (true) {
                val s = nativeEngine.stats()
                statsText = "frames=${s[0]} underrun=${s[1]} urbs=${s[2]}/${s[3]} err=${s[4]}"
                kotlinx.coroutines.delay(1000)
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            exoPlayer.release()
            nativeEngine.stop()
            nativeEngine.release()
            openedDac?.connection?.close()
        }
    }

    LaunchedEffect(selectedUri) {
        selectedUri?.let { uri ->
            exoPlayer.setMediaItem(MediaItem.fromUri(uri))
            exoPlayer.prepare()
        }
    }

    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let {
            try {
                context.contentResolver.takePersistableUriPermission(
                    it, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: SecurityException) { }
            selectedUri = it
            fileName = it.lastPathSegment?.substringAfterLast('/')
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(240.dp)
        ) {
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        player = exoPlayer
                        useController = true
                        setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                filePicker.launch(arrayOf("video/*", "audio/*", "application/octet-stream"))
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Default.FileOpen, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(fileName ?: "Открыть MKV / FLAC")
        }

        Spacer(modifier = Modifier.height(16.dp))

        UsbStatusCard(usbState, statsText)
    }
}

@Composable
private fun UsbStatusCard(state: UsbState, statsText: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Default.Usb, contentDescription = null)
                Text(
                    "USB DAC",
                    style = MaterialTheme.typography.titleMedium
                )
            }
            Spacer(modifier = Modifier.height(8.dp))

            when (state) {
                is UsbState.NotConnected -> Text(
                    "Не подключён. Воткни DT03/DS20 в Type-C.",
                    style = MaterialTheme.typography.bodyMedium
                )
                is UsbState.Connected -> Text(
                    "Найден: ${state.name}. Жду разрешения...",
                    style = MaterialTheme.typography.bodyMedium
                )
                is UsbState.PermissionDenied -> Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Error, contentDescription = null, tint = Color(0xFFE57373))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Доступ отклонён. Перезапусти и нажми OK.")
                }
                is UsbState.Ready -> {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.CheckCircle, contentDescription = null,
                            tint = Color(0xFF81C784)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Bit-perfect готов: ${state.name}")
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        statsText,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                is UsbState.Error -> Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Error, contentDescription = null, tint = Color(0xFFE57373))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(state.message)
                }
            }
        }
    }
}
