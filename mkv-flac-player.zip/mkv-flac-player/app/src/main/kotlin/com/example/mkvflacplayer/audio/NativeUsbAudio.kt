package com.example.mkvflacplayer.audio

/**
 * Тонкая обёртка над нативным USB Audio Engine.
 * Все методы — direct passthrough в C++.
 */
class NativeUsbAudio {

    private var handle: Long = 0L

    init {
        handle = nativeCreate()
    }

    /**
     * fd — файловый дескриптор, полученный из UsbDeviceConnection.fileDescriptor.
     * configDescriptor — полный configuration descriptor, прочитанный через
     * UsbDeviceConnection.controlTransfer (GET_DESCRIPTOR / CONFIGURATION).
     */
    fun init(fd: Int, configDescriptor: ByteArray): Int {
        if (handle == 0L) return ERR_INVALID_FD
        return nativeInit(handle, fd, configDescriptor)
    }

    fun selectFormat(sampleRate: Int, bitDepth: Int, channels: Int): Int {
        if (handle == 0L) return ERR_INVALID_FD
        return nativeSelectFormat(handle, sampleRate, bitDepth, channels)
    }

    fun start(): Int {
        if (handle == 0L) return ERR_INVALID_FD
        return nativeStart(handle)
    }

    fun stop() {
        if (handle != 0L) nativeStop(handle)
    }

    fun writePcm(data: ByteArray, offset: Int, length: Int): Int {
        if (handle == 0L) return 0
        return nativeWritePcm(handle, data, offset, length)
    }

    fun isRunning(): Boolean = handle != 0L && nativeIsRunning(handle)

    /** Возвращает [framesWritten, framesUnderrun, urbsSubmitted, urbsCompleted, urbsErrored] */
    fun stats(): LongArray = if (handle != 0L) nativeGetStats(handle) else LongArray(5)

    fun release() {
        if (handle != 0L) {
            nativeDestroy(handle)
            handle = 0L
        }
    }

    protected fun finalize() {
        release()
    }

    private external fun nativeCreate(): Long
    private external fun nativeDestroy(handle: Long)
    private external fun nativeInit(handle: Long, fd: Int, configDescriptor: ByteArray): Int
    private external fun nativeSelectFormat(handle: Long, sr: Int, bd: Int, ch: Int): Int
    private external fun nativeStart(handle: Long): Int
    private external fun nativeStop(handle: Long)
    private external fun nativeWritePcm(handle: Long, data: ByteArray, offset: Int, length: Int): Int
    private external fun nativeGetStats(handle: Long): LongArray
    private external fun nativeIsRunning(handle: Long): Boolean

    companion object {
        const val OK = 0
        const val ERR_INVALID_FD = -1
        const val ERR_PARSE_FAILED = -2
        const val ERR_NOT_UAC2 = -3
        const val ERR_NO_FORMAT_MATCH = -4
        const val ERR_CLAIM_FAILED = -5
        const val ERR_SETINTERFACE_FAILED = -6
        const val ERR_SET_SAMPLERATE_FAILED = -7
        const val ERR_URB_SUBMIT_FAILED = -8

        fun errorName(code: Int): String = when (code) {
            OK -> "OK"
            ERR_INVALID_FD -> "INVALID_FD"
            ERR_PARSE_FAILED -> "PARSE_FAILED"
            ERR_NOT_UAC2 -> "NOT_UAC2"
            ERR_NO_FORMAT_MATCH -> "NO_FORMAT_MATCH"
            ERR_CLAIM_FAILED -> "CLAIM_FAILED (Android держит устройство — попробуй отключить через настройки USB-audio)"
            ERR_SETINTERFACE_FAILED -> "SETINTERFACE_FAILED"
            ERR_SET_SAMPLERATE_FAILED -> "SET_SAMPLERATE_FAILED"
            ERR_URB_SUBMIT_FAILED -> "URB_SUBMIT_FAILED"
            else -> "UNKNOWN($code)"
        }

        init {
            System.loadLibrary("usbaudio")
        }
    }
}
