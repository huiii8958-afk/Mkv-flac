package com.example.mkvflacplayer.usb

import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbManager
import android.os.Build
import android.util.Log

/**
 * Управляет подключением к USB-ЦАПу:
 * - находит UAC устройство
 * - запрашивает разрешение
 * - открывает соединение
 * - читает full configuration descriptor (нужен для парсинга на нативной стороне)
 */
class UsbDacManager(private val context: Context) {

    private val tag = "UsbDacManager"
    private val usbManager = context.getSystemService(Context.USB_SERVICE) as UsbManager
    private var permissionReceiver: BroadcastReceiver? = null

    data class OpenedDac(
        val device: UsbDevice,
        val connection: UsbDeviceConnection,
        val fileDescriptor: Int,
        val configDescriptor: ByteArray,
    )

    /** Ищет первое UAC-устройство среди подключённых USB. */
    fun findUacDevice(): UsbDevice? {
        for (device in usbManager.deviceList.values) {
            for (i in 0 until device.interfaceCount) {
                val iface = device.getInterface(i)
                if (iface.interfaceClass == UsbConstants.USB_CLASS_AUDIO) {
                    Log.i(tag, "Найден UAC-девайс: ${device.productName} (vid=${device.vendorId}, pid=${device.productId})")
                    return device
                }
            }
        }
        return null
    }

    /** Запрашивает разрешение пользователя на доступ к USB-устройству. */
    @SuppressLint("UnspecifiedRegisterReceiverFlag")
    fun requestPermission(device: UsbDevice, onResult: (Boolean) -> Unit) {
        if (usbManager.hasPermission(device)) {
            onResult(true)
            return
        }

        val action = ACTION_USB_PERMISSION
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PendingIntent.FLAG_MUTABLE
        } else 0
        val intent = PendingIntent.getBroadcast(
            context, 0, Intent(action).setPackage(context.packageName), flags
        )

        permissionReceiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                if (i.action == action) {
                    val granted = i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                    onResult(granted)
                    try {
                        context.unregisterReceiver(this)
                    } catch (_: IllegalArgumentException) { }
                    permissionReceiver = null
                }
            }
        }

        val filter = IntentFilter(action)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.registerReceiver(permissionReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            context.registerReceiver(permissionReceiver, filter)
        }
        usbManager.requestPermission(device, intent)
    }

    /**
     * Открывает устройство и читает полный configuration descriptor.
     * Configuration descriptor нужен на C++-стороне для парсинга UAC2 структур.
     */
    fun openDevice(device: UsbDevice): OpenedDac? {
        val connection = usbManager.openDevice(device) ?: run {
            Log.e(tag, "openDevice вернул null — нет разрешения?")
            return null
        }
        val fd = connection.fileDescriptor
        if (fd < 0) {
            connection.close()
            Log.e(tag, "fileDescriptor < 0")
            return null
        }

        // Чтение config descriptor через стандартный GET_DESCRIPTOR control transfer.
        // Сначала читаем 9 байт чтобы узнать wTotalLength, потом весь дескриптор.
        val short = ByteArray(9)
        val rShort = connection.controlTransfer(
            0x80,    // bmRequestType: device-to-host, standard, device
            0x06,    // GET_DESCRIPTOR
            (0x02 shl 8) or 0,  // wValue: CONFIG descriptor, index 0
            0,
            short, short.size, 1000
        )
        if (rShort < 9) {
            Log.e(tag, "GET_DESCRIPTOR(short) вернул $rShort")
            connection.close()
            return null
        }
        val totalLen = (short[2].toInt() and 0xFF) or ((short[3].toInt() and 0xFF) shl 8)
        val full = ByteArray(totalLen)
        val rFull = connection.controlTransfer(
            0x80, 0x06, (0x02 shl 8) or 0, 0, full, totalLen, 2000
        )
        if (rFull < totalLen) {
            Log.e(tag, "GET_DESCRIPTOR(full) вернул $rFull, ожидалось $totalLen")
            connection.close()
            return null
        }

        Log.i(tag, "Config descriptor прочитан: $totalLen байт")
        return OpenedDac(device, connection, fd, full)
    }

    companion object {
        const val ACTION_USB_PERMISSION = "com.example.mkvflacplayer.USB_PERMISSION"
    }
}
