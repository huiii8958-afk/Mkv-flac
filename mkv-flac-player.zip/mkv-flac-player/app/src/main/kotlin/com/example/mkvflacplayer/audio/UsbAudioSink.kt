package com.example.mkvflacplayer.audio

import android.util.Log
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.AuxEffectInfo
import java.nio.ByteBuffer

/**
 * Кастомный AudioSink, который вместо AudioTrack отдаёт PCM прямо в нативный USB-движок.
 * Тем самым полностью обходит AudioFlinger и всю системную обработку Android.
 */
@UnstableApi
class UsbAudioSink(private val engine: NativeUsbAudio) : AudioSink {

    private val tag = "UsbAudioSink"

    private var listener: AudioSink.Listener? = null
    private var inputFormat: Format? = null

    private var sampleRate = 0
    private var channelCount = 0
    private var pcmEncoding = C.ENCODING_INVALID
    private var bytesPerFrame = 0

    @Volatile private var playing = false
    @Volatile private var ended = false
    private var framesWritten: Long = 0
    private var volume = 1.0f
    private var playbackParameters = PlaybackParameters.DEFAULT

    private val scratch = ByteArray(64 * 1024)

    override fun setListener(listener: AudioSink.Listener?) {
        this.listener = listener
    }

    override fun supportsFormat(format: Format): Boolean = getFormatSupport(format) ==
            AudioSink.SINK_FORMAT_SUPPORTED_DIRECTLY

    override fun getFormatSupport(format: Format): Int {
        // Поддерживаем только PCM (16/24/32 бит) после декодера.
        return when (format.pcmEncoding) {
            C.ENCODING_PCM_16BIT, C.ENCODING_PCM_24BIT, C.ENCODING_PCM_32BIT ->
                AudioSink.SINK_FORMAT_SUPPORTED_DIRECTLY
            else -> AudioSink.SINK_FORMAT_UNSUPPORTED
        }
    }

    override fun configure(inputFormat: Format, specifiedBufferSize: Int, outputChannels: IntArray?) {
        this.inputFormat = inputFormat
        sampleRate = inputFormat.sampleRate
        channelCount = inputFormat.channelCount
        pcmEncoding = inputFormat.pcmEncoding

        val bitDepth = when (pcmEncoding) {
            C.ENCODING_PCM_16BIT -> 16
            C.ENCODING_PCM_24BIT -> 24
            C.ENCODING_PCM_32BIT -> 32
            else -> {
                Log.e(tag, "Неподдерживаемая PCM encoding=$pcmEncoding")
                throw AudioSink.ConfigurationException(
                    "Unsupported PCM encoding: $pcmEncoding", inputFormat
                )
            }
        }
        bytesPerFrame = (bitDepth / 8) * channelCount

        val rc = engine.selectFormat(sampleRate, bitDepth, channelCount)
        if (rc != NativeUsbAudio.OK) {
            Log.e(tag, "selectFormat вернул ${NativeUsbAudio.errorName(rc)}")
            throw AudioSink.ConfigurationException(
                "Native selectFormat failed: ${NativeUsbAudio.errorName(rc)}", inputFormat
            )
        }
        val rs = engine.start()
        if (rs != NativeUsbAudio.OK) {
            Log.e(tag, "start вернул ${NativeUsbAudio.errorName(rs)}")
            throw AudioSink.ConfigurationException(
                "Native start failed: ${NativeUsbAudio.errorName(rs)}", inputFormat
            )
        }
        framesWritten = 0
        ended = false
        Log.i(tag, "AudioSink сконфигурирован: $sampleRate Hz / $bitDepth bit / $channelCount ch")
    }

    override fun play() {
        playing = true
    }

    override fun handleDiscontinuity() {
        // Просто отмечаем, что был разрыв. Можно сбросить буфер на следующем handleBuffer.
    }

    override fun handleBuffer(
        buffer: ByteBuffer,
        presentationTimeUs: Long,
        encodedAccessUnitCount: Int
    ): Boolean {
        if (!playing) return false
        if (!buffer.hasRemaining()) return true

        val remaining = buffer.remaining()
        val toCopy = minOf(remaining, scratch.size)
        buffer.get(scratch, 0, toCopy)

        val written = engine.writePcm(scratch, 0, toCopy)
        if (written < toCopy) {
            // Не всё ушло — откатим позицию buffer'а на непринятые байты
            buffer.position(buffer.position() - (toCopy - written))
        }
        if (bytesPerFrame > 0) {
            framesWritten += written / bytesPerFrame
        }
        return written > 0
    }

    override fun playToEndOfStream() {
        ended = true
    }

    override fun isEnded(): Boolean = ended

    override fun hasPendingData(): Boolean = playing && !ended

    override fun setPlaybackParameters(playbackParameters: PlaybackParameters) {
        // Изменение скорости в нативном движке не поддерживаем — отдаём дефолт.
        this.playbackParameters = PlaybackParameters.DEFAULT
    }

    override fun getPlaybackParameters(): PlaybackParameters = playbackParameters

    override fun setSkipSilenceEnabled(skipSilenceEnabled: Boolean) { /* no-op */ }
    override fun getSkipSilenceEnabled(): Boolean = false

    override fun setAudioAttributes(audioAttributes: AudioAttributes) { /* no-op */ }
    override fun getAudioAttributes(): AudioAttributes? = null

    override fun setAudioSessionId(audioSessionId: Int) { /* no-op */ }
    override fun setAuxEffectInfo(auxEffectInfo: AuxEffectInfo) { /* no-op */ }

    override fun getCurrentPositionUs(sourceEnded: Boolean): Long {
        if (sampleRate <= 0) return CURRENT_POSITION_NOT_SET
        return framesWritten * 1_000_000L / sampleRate
    }

    override fun setVolume(volume: Float) {
        // Громкость — программная, лучше управлять железной кнопкой DAC.
        // Здесь оставим заглушку: применять её в нативном движке = сделать НЕ bit-perfect.
        this.volume = volume
    }

    override fun pause() {
        playing = false
    }

    override fun flush() {
        framesWritten = 0
        ended = false
    }

    override fun reset() {
        flush()
        engine.stop()
    }

    fun release() {
        engine.stop()
    }

    companion object {
        const val CURRENT_POSITION_NOT_SET = AudioSink.CURRENT_POSITION_NOT_SET
    }
}
