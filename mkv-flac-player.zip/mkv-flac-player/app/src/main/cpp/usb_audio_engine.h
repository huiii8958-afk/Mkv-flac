// usb_audio_engine.h
// Прямой вывод PCM в USB DAC через Linux usbdevfs ioctls.
// Обходит весь Android-аудиостек.

#pragma once

#include "uac2_descriptors.h"
#include <atomic>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <vector>
#include <cstdint>
#include <cstddef>

namespace usbaudio {

enum class EngineError {
    OK = 0,
    INVALID_FD = -1,
    PARSE_FAILED = -2,
    NOT_UAC2 = -3,
    NO_FORMAT_MATCH = -4,
    CLAIM_FAILED = -5,
    SETINTERFACE_FAILED = -6,
    SET_SAMPLERATE_FAILED = -7,
    URB_SUBMIT_FAILED = -8,
    NOT_RUNNING = -9,
};

struct EngineStats {
    uint64_t framesWritten;
    uint64_t framesUnderrun;
    uint64_t urbsSubmitted;
    uint64_t urbsCompleted;
    uint64_t urbsErrored;
};

class UsbAudioEngine {
public:
    UsbAudioEngine();
    ~UsbAudioEngine();

    // fd — файловый дескриптор из Android UsbDeviceConnection.getFileDescriptor()
    // configDescriptor — буфер с full config descriptor (включая class-specific)
    EngineError init(int fd, const uint8_t* configDescriptor, size_t descLen);

    // Выбор формата. Sample rate выставляется через UAC2 Clock Source control.
    EngineError selectFormat(uint32_t sampleRate, uint8_t bitDepth, uint8_t channels);

    // Запускает потоки и начинает отправлять URB. После start() можно writePcm().
    EngineError start();

    // Останавливает потоки, отменяет все URB, освобождает interface.
    void stop();

    // Запись PCM в кольцевой буфер. Может блокировать, если буфер полон.
    // data: интерливед PCM в формате, выбранном selectFormat().
    // bytes: размер в байтах.
    // Возвращает фактически записанное количество байт.
    size_t writePcm(const uint8_t* data, size_t bytes);

    EngineStats getStats() const;

    bool isRunning() const { return running_.load(); }

private:
    // Управление устройством
    int fd_;                           // не владеем, не закрываем
    UacDeviceInfo deviceInfo_;
    int selectedAltIdx_;
    AudioStreamingAltSetting currentAlt_;

    // Параметры выбранного формата
    uint32_t sampleRate_;
    uint8_t bitDepth_;
    uint8_t channels_;
    uint8_t bytesPerFrame_;            // channels * subframeSize

    // Кольцевой буфер для PCM
    std::vector<uint8_t> ringBuffer_;
    std::atomic<size_t> ringWritePos_;
    std::atomic<size_t> ringReadPos_;
    size_t ringCapacity_;
    std::mutex ringMutex_;
    std::condition_variable ringNotFull_;
    std::condition_variable ringNotEmpty_;

    // Потоки
    std::atomic<bool> running_;
    std::thread submitThread_;
    std::thread reapThread_;

    // Стек URB-структур, которые мы подаём в очередь ядру
    static constexpr int URB_COUNT = 8;        // глубина очереди
    static constexpr int PACKETS_PER_URB = 8;  // микрофреймов на URB
    struct UrbSlot;
    std::vector<UrbSlot> urbSlots_;

    // Статистика
    mutable std::mutex statsMutex_;
    EngineStats stats_;

    // Внутренние методы
    bool claimInterface(uint8_t interfaceNumber);
    bool releaseInterface(uint8_t interfaceNumber);
    bool setAltSetting(uint8_t interfaceNumber, uint8_t altSetting);
    bool setSampleRateControl(uint8_t clockSourceId, uint32_t sampleRate);
    bool submitUrb(int slotIndex);
    void submitLoop();
    void reapLoop();
    size_t fillUrbFromRing(uint8_t* dst, size_t maxBytes);
};

} // namespace usbaudio
