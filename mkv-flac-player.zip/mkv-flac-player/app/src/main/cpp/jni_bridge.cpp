// jni_bridge.cpp — экспорт UsbAudioEngine в Kotlin через JNI

#include "usb_audio_engine.h"
#include <jni.h>
#include <android/log.h>
#include <memory>

#define LOG_TAG "UsbAudioJni"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

using usbaudio::UsbAudioEngine;
using usbaudio::EngineError;

static inline UsbAudioEngine* asEngine(jlong handle) {
    return reinterpret_cast<UsbAudioEngine*>(handle);
}

extern "C" {

JNIEXPORT jlong JNICALL
Java_com_example_mkvflacplayer_audio_NativeUsbAudio_nativeCreate(
        JNIEnv* env, jobject thiz) {
    auto* engine = new UsbAudioEngine();
    return reinterpret_cast<jlong>(engine);
}

JNIEXPORT void JNICALL
Java_com_example_mkvflacplayer_audio_NativeUsbAudio_nativeDestroy(
        JNIEnv* env, jobject thiz, jlong handle) {
    auto* engine = asEngine(handle);
    if (engine) delete engine;
}

JNIEXPORT jint JNICALL
Java_com_example_mkvflacplayer_audio_NativeUsbAudio_nativeInit(
        JNIEnv* env, jobject thiz, jlong handle, jint fd, jbyteArray configDesc) {
    auto* engine = asEngine(handle);
    if (!engine) return static_cast<jint>(EngineError::INVALID_FD);

    jsize len = env->GetArrayLength(configDesc);
    jbyte* bytes = env->GetByteArrayElements(configDesc, nullptr);
    if (!bytes) return static_cast<jint>(EngineError::PARSE_FAILED);

    EngineError err = engine->init(
            static_cast<int>(fd),
            reinterpret_cast<const uint8_t*>(bytes),
            static_cast<size_t>(len));

    env->ReleaseByteArrayElements(configDesc, bytes, JNI_ABORT);
    return static_cast<jint>(err);
}

JNIEXPORT jint JNICALL
Java_com_example_mkvflacplayer_audio_NativeUsbAudio_nativeSelectFormat(
        JNIEnv* env, jobject thiz, jlong handle,
        jint sampleRate, jint bitDepth, jint channels) {
    auto* engine = asEngine(handle);
    if (!engine) return static_cast<jint>(EngineError::INVALID_FD);
    return static_cast<jint>(engine->selectFormat(
            static_cast<uint32_t>(sampleRate),
            static_cast<uint8_t>(bitDepth),
            static_cast<uint8_t>(channels)));
}

JNIEXPORT jint JNICALL
Java_com_example_mkvflacplayer_audio_NativeUsbAudio_nativeStart(
        JNIEnv* env, jobject thiz, jlong handle) {
    auto* engine = asEngine(handle);
    if (!engine) return static_cast<jint>(EngineError::INVALID_FD);
    return static_cast<jint>(engine->start());
}

JNIEXPORT void JNICALL
Java_com_example_mkvflacplayer_audio_NativeUsbAudio_nativeStop(
        JNIEnv* env, jobject thiz, jlong handle) {
    auto* engine = asEngine(handle);
    if (engine) engine->stop();
}

JNIEXPORT jint JNICALL
Java_com_example_mkvflacplayer_audio_NativeUsbAudio_nativeWritePcm(
        JNIEnv* env, jobject thiz, jlong handle,
        jbyteArray data, jint offset, jint length) {
    auto* engine = asEngine(handle);
    if (!engine) return 0;

    jbyte* bytes = env->GetByteArrayElements(data, nullptr);
    if (!bytes) return 0;

    size_t written = engine->writePcm(
            reinterpret_cast<const uint8_t*>(bytes + offset),
            static_cast<size_t>(length));

    env->ReleaseByteArrayElements(data, bytes, JNI_ABORT);
    return static_cast<jint>(written);
}

JNIEXPORT jlongArray JNICALL
Java_com_example_mkvflacplayer_audio_NativeUsbAudio_nativeGetStats(
        JNIEnv* env, jobject thiz, jlong handle) {
    auto* engine = asEngine(handle);
    jlongArray result = env->NewLongArray(5);
    if (!engine || !result) return result;

    auto s = engine->getStats();
    jlong values[5] = {
            static_cast<jlong>(s.framesWritten),
            static_cast<jlong>(s.framesUnderrun),
            static_cast<jlong>(s.urbsSubmitted),
            static_cast<jlong>(s.urbsCompleted),
            static_cast<jlong>(s.urbsErrored),
    };
    env->SetLongArrayRegion(result, 0, 5, values);
    return result;
}

JNIEXPORT jboolean JNICALL
Java_com_example_mkvflacplayer_audio_NativeUsbAudio_nativeIsRunning(
        JNIEnv* env, jobject thiz, jlong handle) {
    auto* engine = asEngine(handle);
    return engine && engine->isRunning() ? JNI_TRUE : JNI_FALSE;
}

} // extern "C"
