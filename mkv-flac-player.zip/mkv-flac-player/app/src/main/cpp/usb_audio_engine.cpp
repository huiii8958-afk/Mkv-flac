// usb_audio_engine.cpp
// Прямые isochronous transfers через Linux usbdevfs ioctl.
// Аналог того, что libusb делает внутри, только без линковки libusb.

#include "usb_audio_engine.h"

#include <linux/usbdevice_fs.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <errno.h>
#include <cstring>
#include <cstdlib>
#include <algorithm>
#include <android/log.h>

#define LOG_TAG "UsbAudioEngine"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace usbaudio {

namespace {

// UAC2 Class-Specific Request коды
constexpr uint8_t UAC2_CUR = 0x01;
constexpr uint8_t UAC2_RANGE = 0x02;

// UAC2 Clock Source Control Selectors
constexpr uint8_t CS_SAM_FREQ_CONTROL = 0x01;

// bmRequestType для class-specific interface set
constexpr uint8_t BMREQ_CLASS_INTERFACE_SET = 0x21;

// Размер ring buffer: ~250ms аудио при 48000*2*2 = 192000 bytes/sec → 48 KB
// Для безопасности возьмём 256 KB.
constexpr size_t RING_BUFFER_SIZE = 256 * 1024;

} // anonymous namespace

// Один URB-слот: память под URB+iso_frame_desc + аудио буфер
struct UsbAudioEngine::UrbSlot {
    std::vector<uint8_t> urbStorage;   // sizeof(usbdevfs_urb) + N * sizeof(iso_packet_desc)
    std::vector<uint8_t> dataBuffer;   // PCM payload
    bool inFlight = false;
    int slotIndex = 0;

    usbdevfs_urb* urb() {
        return reinterpret_cast<usbdevfs_urb*>(urbStorage.data());
    }
    usbdevfs_iso_packet_desc* packets() {
        return reinterpret_cast<usbdevfs_iso_packet_desc*>(
                urbStorage.data() + sizeof(usbdevfs_urb));
    }
};

UsbAudioEngine::UsbAudioEngine()
        : fd_(-1)
        , selectedAltIdx_(-1)
        , sampleRate_(0)
        , bitDepth_(0)
        , channels_(0)
        , bytesPerFrame_(0)
        , ringWritePos_(0)
        , ringReadPos_(0)
        , ringCapacity_(0)
        , running_(false)
        , stats_{} {
}

UsbAudioEngine::~UsbAudioEngine() {
    stop();
}

EngineError UsbAudioEngine::init(int fd, const uint8_t* configDescriptor, size_t descLen) {
    if (fd < 0) return EngineError::INVALID_FD;
    fd_ = fd;

    deviceInfo_ = parseUacDescriptors(configDescriptor, descLen);
    if (deviceInfo_.altSettings.empty()) {
        LOGE("Дескрипторы не разобраны или нет аудио-альт-настроек");
        return EngineError::PARSE_FAILED;
    }
    if (!deviceInfo_.isUac2) {
        LOGW("Устройство не UAC2 — продолжим, но без гарантий");
    }

    return EngineError::OK;
}

EngineError UsbAudioEngine::selectFormat(uint32_t sampleRate, uint8_t bitDepth, uint8_t channels) {
    int idx = selectBestAltSetting(deviceInfo_, sampleRate, bitDepth, channels);
    if (idx < 0) {
        LOGE("Не нашлось альт-настройки под %u Hz / %u bit / %u ch",
             sampleRate, bitDepth, channels);
        return EngineError::NO_FORMAT_MATCH;
    }
    selectedAltIdx_ = idx;
    currentAlt_ = deviceInfo_.altSettings[idx];
    sampleRate_ = sampleRate;
    bitDepth_ = bitDepth;
    channels_ = channels;
    bytesPerFrame_ = static_cast<uint8_t>(currentAlt_.format.subframeSize * channels);

    LOGI("Выбрана альт-настройка #%d: bit=%u, channels=%u, ep=0x%02x, maxPkt=%u, sync=%u",
         currentAlt_.altSetting, currentAlt_.format.bitResolution,
         currentAlt_.format.channels, currentAlt_.audioEndpoint,
         currentAlt_.audioMaxPacketSize, currentAlt_.syncType);

    return EngineError::OK;
}

bool UsbAudioEngine::claimInterface(uint8_t interfaceNumber) {
    unsigned int iface = interfaceNumber;
    if (ioctl(fd_, USBDEVFS_CLAIMINTERFACE, &iface) < 0) {
        LOGE("CLAIMINTERFACE %u: errno=%d (%s)", interfaceNumber, errno, strerror(errno));
        return false;
    }
    return true;
}

bool UsbAudioEngine::releaseInterface(uint8_t interfaceNumber) {
    unsigned int iface = interfaceNumber;
    if (ioctl(fd_, USBDEVFS_RELEASEINTERFACE, &iface) < 0) {
        LOGW("RELEASEINTERFACE %u: errno=%d", interfaceNumber, errno);
        return false;
    }
    return true;
}

bool UsbAudioEngine::setAltSetting(uint8_t interfaceNumber, uint8_t altSetting) {
    usbdevfs_setinterface si{};
    si.interface = interfaceNumber;
    si.altsetting = altSetting;
    if (ioctl(fd_, USBDEVFS_SETINTERFACE, &si) < 0) {
        LOGE("SETINTERFACE %u/%u: errno=%d (%s)",
             interfaceNumber, altSetting, errno, strerror(errno));
        return false;
    }
    return true;
}

bool UsbAudioEngine::setSampleRateControl(uint8_t clockSourceId, uint32_t sampleRate) {
    // UAC2 §5.2.5.1.1: SET_CUR на Clock Source, control selector CS_SAM_FREQ_CONTROL.
    // wValue = (CS_SAM_FREQ_CONTROL << 8)
    // wIndex = (clockSourceId << 8) | controlInterfaceNumber
    // wLength = 4, data = sampleRate (little-endian, 4 bytes)
    uint32_t rate = sampleRate;
    usbdevfs_ctrltransfer ct{};
    ct.bRequestType = BMREQ_CLASS_INTERFACE_SET;
    ct.bRequest = UAC2_CUR;
    ct.wValue = static_cast<uint16_t>(CS_SAM_FREQ_CONTROL << 8);
    ct.wIndex = static_cast<uint16_t>((clockSourceId << 8) | deviceInfo_.controlInterfaceNumber);
    ct.wLength = 4;
    ct.timeout = 1000;
    ct.data = &rate;

    int n = ioctl(fd_, USBDEVFS_CONTROL, &ct);
    if (n < 0) {
        LOGE("Set sample rate %u Hz failed: errno=%d (%s)",
             sampleRate, errno, strerror(errno));
        return false;
    }
    LOGI("Sample rate %u Hz установлен на Clock Source %u", sampleRate, clockSourceId);
    return true;
}

EngineError UsbAudioEngine::start() {
    if (running_.load()) return EngineError::OK;
    if (selectedAltIdx_ < 0) return EngineError::NO_FORMAT_MATCH;

    // Сначала "обнуляем" альт-настройку (alt=0 = no bandwidth)
    setAltSetting(currentAlt_.interfaceNumber, 0);

    // Claim
    if (!claimInterface(currentAlt_.interfaceNumber)) {
        return EngineError::CLAIM_FAILED;
    }

    // Set alt setting (выделяет bandwidth)
    if (!setAltSetting(currentAlt_.interfaceNumber, currentAlt_.altSetting)) {
        releaseInterface(currentAlt_.interfaceNumber);
        return EngineError::SETINTERFACE_FAILED;
    }

    // Set sample rate — clockSourceId обычно 0x09 или 0x10, но мы не знаем без парсинга AC.
    // ВРЕМЕННО: попробуем clockSourceId=0x09 (типичный для xCORE/XMOS, как у DT03).
    // TODO: парсить AC interface descriptors и брать настоящий ID.
    uint8_t guessedClockId = 0x09;
    if (!setSampleRateControl(guessedClockId, sampleRate_)) {
        // Попробуем 0x10
        if (!setSampleRateControl(0x10, sampleRate_)) {
            LOGW("Sample rate не установился — DAC может работать на дефолтной частоте");
        }
    }

    // Подготовка ring buffer
    ringCapacity_ = RING_BUFFER_SIZE;
    ringBuffer_.assign(ringCapacity_, 0);
    ringWritePos_.store(0);
    ringReadPos_.store(0);

    // Подготовка URB-слотов
    urbSlots_.clear();
    urbSlots_.resize(URB_COUNT);
    size_t maxPkt = currentAlt_.audioMaxPacketSize;
    size_t urbStructSize = sizeof(usbdevfs_urb)
                           + PACKETS_PER_URB * sizeof(usbdevfs_iso_packet_desc);
    for (int i = 0; i < URB_COUNT; ++i) {
        auto& slot = urbSlots_[i];
        slot.slotIndex = i;
        slot.urbStorage.assign(urbStructSize, 0);
        slot.dataBuffer.assign(maxPkt * PACKETS_PER_URB, 0);
        slot.inFlight = false;
    }

    running_.store(true);

    // Запуск потоков
    submitThread_ = std::thread(&UsbAudioEngine::submitLoop, this);
    reapThread_ = std::thread(&UsbAudioEngine::reapLoop, this);

    LOGI("Engine started: %u Hz, %u-bit, %u ch", sampleRate_, bitDepth_, channels_);
    return EngineError::OK;
}

void UsbAudioEngine::stop() {
    if (!running_.exchange(false)) return;

    ringNotEmpty_.notify_all();
    ringNotFull_.notify_all();

    if (submitThread_.joinable()) submitThread_.join();
    if (reapThread_.joinable()) reapThread_.join();

    // Отмена всех URB
    for (auto& slot : urbSlots_) {
        if (slot.inFlight) {
            ioctl(fd_, USBDEVFS_DISCARDURB, slot.urb());
        }
    }

    // Возвращаем alt=0, освобождаем
    setAltSetting(currentAlt_.interfaceNumber, 0);
    releaseInterface(currentAlt_.interfaceNumber);

    urbSlots_.clear();
    ringBuffer_.clear();
    LOGI("Engine stopped");
}

size_t UsbAudioEngine::fillUrbFromRing(uint8_t* dst, size_t maxBytes) {
    size_t written = 0;
    size_t cap = ringCapacity_;
    while (written < maxBytes) {
        size_t r = ringReadPos_.load(std::memory_order_acquire);
        size_t w = ringWritePos_.load(std::memory_order_acquire);
        size_t avail = (w >= r) ? (w - r) : (cap - r + w);
        if (avail == 0) break;
        size_t chunk = std::min({maxBytes - written, avail, cap - r});
        std::memcpy(dst + written, ringBuffer_.data() + r, chunk);
        size_t newR = (r + chunk) % cap;
        ringReadPos_.store(newR, std::memory_order_release);
        written += chunk;
    }
    if (written < maxBytes) {
        // Underrun: набиваем тишиной
        std::memset(dst + written, 0, maxBytes - written);
        std::lock_guard<std::mutex> lk(statsMutex_);
        stats_.framesUnderrun += (maxBytes - written) / bytesPerFrame_;
    }
    ringNotFull_.notify_one();
    return maxBytes;
}

bool UsbAudioEngine::submitUrb(int slotIndex) {
    auto& slot = urbSlots_[slotIndex];
    usbdevfs_urb* urb = slot.urb();

    size_t maxPkt = currentAlt_.audioMaxPacketSize;
    size_t totalBytes = maxPkt * PACKETS_PER_URB;

    // Заполняем PCM из ring buffer
    fillUrbFromRing(slot.dataBuffer.data(), totalBytes);

    std::memset(urb, 0, sizeof(usbdevfs_urb));
    urb->type = USBDEVFS_URB_TYPE_ISO;
    urb->endpoint = currentAlt_.audioEndpoint;
    urb->status = 0;
    urb->flags = USBDEVFS_URB_ISO_ASAP;
    urb->buffer = slot.dataBuffer.data();
    urb->buffer_length = static_cast<int>(totalBytes);
    urb->number_of_packets = PACKETS_PER_URB;
    urb->usercontext = reinterpret_cast<void*>(static_cast<intptr_t>(slotIndex));

    auto* packets = slot.packets();
    for (int i = 0; i < PACKETS_PER_URB; ++i) {
        packets[i].length = maxPkt;
        packets[i].actual_length = 0;
        packets[i].status = 0;
    }

    if (ioctl(fd_, USBDEVFS_SUBMITURB, urb) < 0) {
        LOGE("SUBMITURB slot=%d errno=%d (%s)", slotIndex, errno, strerror(errno));
        return false;
    }

    slot.inFlight = true;
    {
        std::lock_guard<std::mutex> lk(statsMutex_);
        stats_.urbsSubmitted++;
    }
    return true;
}

void UsbAudioEngine::submitLoop() {
    // Предзапускаем все URB
    for (int i = 0; i < URB_COUNT; ++i) {
        if (!running_.load()) return;
        submitUrb(i);
    }
    // Дальше повторная отправка происходит из reapLoop()
    while (running_.load()) {
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
}

void UsbAudioEngine::reapLoop() {
    while (running_.load()) {
        usbdevfs_urb* reaped = nullptr;
        int r = ioctl(fd_, USBDEVFS_REAPURBNDELAY, &reaped);
        if (r < 0) {
            if (errno == EAGAIN) {
                std::this_thread::sleep_for(std::chrono::microseconds(500));
                continue;
            }
            if (errno == ENODEV) {
                LOGE("Устройство отключено");
                running_.store(false);
                break;
            }
            LOGW("REAPURB errno=%d (%s)", errno, strerror(errno));
            continue;
        }
        if (!reaped) continue;

        int slotIndex = static_cast<int>(reinterpret_cast<intptr_t>(reaped->usercontext));
        if (slotIndex < 0 || slotIndex >= URB_COUNT) {
            LOGW("Reaped URB с битым slotIndex=%d", slotIndex);
            continue;
        }
        auto& slot = urbSlots_[slotIndex];
        slot.inFlight = false;

        {
            std::lock_guard<std::mutex> lk(statsMutex_);
            stats_.urbsCompleted++;
            if (reaped->status != 0) stats_.urbsErrored++;
            stats_.framesWritten += reaped->actual_length / std::max<uint8_t>(bytesPerFrame_, 1);
        }

        // Повторная отправка
        if (running_.load()) {
            submitUrb(slotIndex);
        }
    }
}

size_t UsbAudioEngine::writePcm(const uint8_t* data, size_t bytes) {
    if (!running_.load()) return 0;

    std::unique_lock<std::mutex> lk(ringMutex_);
    size_t written = 0;
    size_t cap = ringCapacity_;

    while (written < bytes && running_.load()) {
        size_t r = ringReadPos_.load(std::memory_order_acquire);
        size_t w = ringWritePos_.load(std::memory_order_acquire);
        size_t used = (w >= r) ? (w - r) : (cap - r + w);
        size_t free = cap - used - 1;  // -1 чтобы различать full/empty

        if (free == 0) {
            ringNotFull_.wait_for(lk, std::chrono::milliseconds(50));
            continue;
        }
        size_t chunk = std::min({bytes - written, free, cap - w});
        std::memcpy(ringBuffer_.data() + w, data + written, chunk);
        size_t newW = (w + chunk) % cap;
        ringWritePos_.store(newW, std::memory_order_release);
        written += chunk;
        ringNotEmpty_.notify_one();
    }
    return written;
}

EngineStats UsbAudioEngine::getStats() const {
    std::lock_guard<std::mutex> lk(statsMutex_);
    return stats_;
}

} // namespace usbaudio
