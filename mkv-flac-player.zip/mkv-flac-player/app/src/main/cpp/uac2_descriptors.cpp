// uac2_descriptors.cpp
#include "uac2_descriptors.h"
#include <cstring>
#include <android/log.h>

#define LOG_TAG "UacDesc"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)

namespace usbaudio {

namespace {

// Структура: дескриптор начинается с bLength, bDescriptorType
struct DescHeader {
    uint8_t bLength;
    uint8_t bDescriptorType;
} __attribute__((packed));

// Стандартный interface descriptor
struct InterfaceDesc {
    uint8_t bLength;
    uint8_t bDescriptorType;
    uint8_t bInterfaceNumber;
    uint8_t bAlternateSetting;
    uint8_t bNumEndpoints;
    uint8_t bInterfaceClass;
    uint8_t bInterfaceSubClass;
    uint8_t bInterfaceProtocol;
    uint8_t iInterface;
} __attribute__((packed));

// Стандартный endpoint descriptor
struct EndpointDesc {
    uint8_t bLength;
    uint8_t bDescriptorType;
    uint8_t bEndpointAddress;
    uint8_t bmAttributes;
    uint16_t wMaxPacketSize;
    uint8_t bInterval;
} __attribute__((packed));

// UAC2 AS_GENERAL (CS interface descriptor, subtype AS_GENERAL)
struct AsGeneralDesc {
    uint8_t bLength;
    uint8_t bDescriptorType;     // CS_INTERFACE
    uint8_t bDescriptorSubtype;  // AS_GENERAL
    uint8_t bTerminalLink;
    uint8_t bmControls;
    uint8_t bFormatType;
    uint32_t bmFormats;
    uint8_t bNrChannels;
    uint32_t bmChannelConfig;
    uint8_t iChannelNames;
} __attribute__((packed));

// UAC2 Type I Format Type descriptor
struct FormatTypeIDesc {
    uint8_t bLength;
    uint8_t bDescriptorType;
    uint8_t bDescriptorSubtype;
    uint8_t bFormatType;
    uint8_t bSubslotSize;
    uint8_t bBitResolution;
} __attribute__((packed));

inline uint16_t readU16(const uint8_t* p) {
    return static_cast<uint16_t>(p[0]) | (static_cast<uint16_t>(p[1]) << 8);
}

} // anonymous namespace

UacDeviceInfo parseUacDescriptors(const uint8_t* data, size_t length) {
    UacDeviceInfo result{};
    result.controlInterfaceNumber = 0xFF;
    result.streamingInterfaceNumber = 0xFF;
    result.isUac2 = false;

    if (!data || length < 9) return result;

    size_t offset = 0;
    // Пропускаем config descriptor (9 байт)
    if (data[1] == USB_DT_CONFIG) {
        offset = data[0];
    }

    const InterfaceDesc* currentInterface = nullptr;
    AudioStreamingAltSetting currentAlt{};
    bool inAudioStreaming = false;

    auto commitAlt = [&]() {
        if (inAudioStreaming && currentAlt.audioEndpoint != 0) {
            result.altSettings.push_back(currentAlt);
        }
        currentAlt = AudioStreamingAltSetting{};
        inAudioStreaming = false;
    };

    while (offset + 2 <= length) {
        uint8_t descLen = data[offset];
        uint8_t descType = data[offset + 1];
        if (descLen == 0 || offset + descLen > length) break;

        const uint8_t* desc = data + offset;

        if (descType == USB_DT_INTERFACE && descLen >= sizeof(InterfaceDesc)) {
            // Новый интерфейс — закрываем предыдущую альт-настройку
            commitAlt();

            currentInterface = reinterpret_cast<const InterfaceDesc*>(desc);

            if (currentInterface->bInterfaceClass == USB_CLASS_AUDIO) {
                if (currentInterface->bInterfaceSubClass == USB_SUBCLASS_AUDIOCONTROL) {
                    result.controlInterfaceNumber = currentInterface->bInterfaceNumber;
                    if (currentInterface->bInterfaceProtocol == USB_AUDIO_PROTOCOL_V2) {
                        result.isUac2 = true;
                    }
                } else if (currentInterface->bInterfaceSubClass == USB_SUBCLASS_AUDIOSTREAMING) {
                    if (currentInterface->bInterfaceProtocol == USB_AUDIO_PROTOCOL_V2 &&
                        currentInterface->bNumEndpoints > 0) {
                        // Стартуем новую альт-настройку
                        currentAlt.interfaceNumber = currentInterface->bInterfaceNumber;
                        currentAlt.altSetting = currentInterface->bAlternateSetting;
                        result.streamingInterfaceNumber = currentInterface->bInterfaceNumber;
                        inAudioStreaming = true;
                    }
                }
            }
        } else if (inAudioStreaming && descType == USB_DT_CS_INTERFACE && descLen >= 3) {
            uint8_t subtype = desc[2];
            if (subtype == AS_GENERAL && descLen >= sizeof(AsGeneralDesc)) {
                const auto* g = reinterpret_cast<const AsGeneralDesc*>(desc);
                currentAlt.terminalLink = g->bTerminalLink;
                currentAlt.format.channels = g->bNrChannels;
            } else if (subtype == AS_FORMAT_TYPE && descLen >= sizeof(FormatTypeIDesc)) {
                const auto* f = reinterpret_cast<const FormatTypeIDesc*>(desc);
                if (f->bFormatType == FORMAT_TYPE_I) {
                    currentAlt.format.subframeSize = f->bSubslotSize;
                    currentAlt.format.bitResolution = f->bBitResolution;
                }
            }
        } else if (inAudioStreaming && descType == USB_DT_ENDPOINT && descLen >= sizeof(EndpointDesc)) {
            const auto* ep = reinterpret_cast<const EndpointDesc*>(desc);
            uint8_t addr = ep->bEndpointAddress;
            uint8_t syncType = (ep->bmAttributes >> 2) & 0x03;
            uint8_t usageType = (ep->bmAttributes >> 4) & 0x03;

            // usageType: 0 = data, 1 = feedback, 2 = implicit feedback data
            if (usageType == 0) {
                currentAlt.audioEndpoint = addr;
                currentAlt.audioMaxPacketSize = ep->wMaxPacketSize & 0x07FF;
                currentAlt.syncType = syncType;
                currentAlt.bInterval = ep->bInterval;
            } else if (usageType == 1) {
                currentAlt.feedbackEndpoint = addr;
                currentAlt.feedbackMaxPacketSize = ep->wMaxPacketSize & 0x07FF;
            }
        }

        offset += descLen;
    }
    commitAlt();

    LOGI("Найдено альт-настроек: %zu, UAC2: %d, AC interface: %d, AS interface: %d",
         result.altSettings.size(), result.isUac2,
         result.controlInterfaceNumber, result.streamingInterfaceNumber);

    return result;
}

int selectBestAltSetting(
        const UacDeviceInfo& info,
        uint32_t desiredSampleRate,
        uint8_t desiredBitDepth,
        uint8_t desiredChannels) {
    // ВАЖНО: в UAC2 список поддерживаемых sample rates получается через
    // class-specific control запрос RANGE к Clock Source. На этапе разбора
    // дескрипторов мы их не знаем. Поэтому выбираем по битности+каналам,
    // а sample rate выставим уже control-запросом.

    int bestIdx = -1;
    int bestScore = -1;

    for (size_t i = 0; i < info.altSettings.size(); ++i) {
        const auto& a = info.altSettings[i];
        // Альт-настройка 0 обычно "zero bandwidth" — пропускаем
        if (a.altSetting == 0) continue;
        if (a.audioEndpoint == 0) continue;
        if (a.format.channels != desiredChannels) continue;

        int score = 0;
        if (a.format.bitResolution == desiredBitDepth) {
            score = 100;
        } else if (a.format.bitResolution >= desiredBitDepth) {
            // Можем играть с большей разрядностью, паддя нулями
            score = 50 - (a.format.bitResolution - desiredBitDepth);
        } else {
            // Меньшая разрядность — теряем данные, не подходит
            continue;
        }

        if (score > bestScore) {
            bestScore = score;
            bestIdx = static_cast<int>(i);
        }
    }

    return bestIdx;
}

} // namespace usbaudio
