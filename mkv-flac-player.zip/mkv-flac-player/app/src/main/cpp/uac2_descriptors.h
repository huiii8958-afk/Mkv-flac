// uac2_descriptors.h
// Парсинг дескрипторов USB Audio Class 2.0
// На основе спецификации USB Device Class Definition for Audio Devices, Release 2.0

#pragma once

#include <cstdint>
#include <vector>
#include <string>

namespace usbaudio {

// USB descriptor types
constexpr uint8_t USB_DT_DEVICE = 0x01;
constexpr uint8_t USB_DT_CONFIG = 0x02;
constexpr uint8_t USB_DT_INTERFACE = 0x04;
constexpr uint8_t USB_DT_ENDPOINT = 0x05;
constexpr uint8_t USB_DT_INTERFACE_ASSOCIATION = 0x0B;
constexpr uint8_t USB_DT_CS_INTERFACE = 0x24;
constexpr uint8_t USB_DT_CS_ENDPOINT = 0x25;

// USB Audio Class
constexpr uint8_t USB_CLASS_AUDIO = 0x01;
constexpr uint8_t USB_SUBCLASS_AUDIOCONTROL = 0x01;
constexpr uint8_t USB_SUBCLASS_AUDIOSTREAMING = 0x02;
constexpr uint8_t USB_AUDIO_PROTOCOL_V2 = 0x20;

// UAC2 Class-specific AS interface descriptor subtypes
constexpr uint8_t AS_GENERAL = 0x01;
constexpr uint8_t AS_FORMAT_TYPE = 0x02;

// UAC2 Format types
constexpr uint8_t FORMAT_TYPE_I = 0x01;

// UAC2 AC interface descriptor subtypes
constexpr uint8_t AC_HEADER = 0x01;
constexpr uint8_t AC_CLOCK_SOURCE = 0x0A;
constexpr uint8_t AC_CLOCK_SELECTOR = 0x0B;

// UAC2 Endpoint sync types
constexpr uint8_t SYNC_TYPE_NO_SYNC = 0x00;
constexpr uint8_t SYNC_TYPE_ASYNC = 0x01;
constexpr uint8_t SYNC_TYPE_ADAPTIVE = 0x02;
constexpr uint8_t SYNC_TYPE_SYNC = 0x03;

// Описывает один формат, который поддерживает альт-настройка
struct AudioFormat {
    uint8_t bitResolution;       // например 16, 24, 32
    uint8_t subframeSize;        // байт на сэмпл (обычно равен bitResolution / 8 округлённо вверх)
    uint8_t channels;
    std::vector<uint32_t> sampleRates;  // поддерживаемые частоты
};

// Описывает одну альтернативную настройку аудио-стрим-интерфейса
struct AudioStreamingAltSetting {
    uint8_t interfaceNumber;
    uint8_t altSetting;
    uint8_t terminalLink;
    uint8_t clockSourceId;
    AudioFormat format;

    // Endpoint для передачи аудио (OUT для playback)
    uint8_t audioEndpoint;
    uint16_t audioMaxPacketSize;
    uint8_t syncType;           // SYNC_TYPE_*
    uint8_t bInterval;          // от endpoint descriptor

    // Feedback endpoint (для async)
    uint8_t feedbackEndpoint;   // 0 если нет
    uint16_t feedbackMaxPacketSize;
};

struct UacDeviceInfo {
    uint8_t controlInterfaceNumber;
    uint8_t streamingInterfaceNumber;
    std::vector<AudioStreamingAltSetting> altSettings;
    bool isUac2;
};

// Парсит configuration descriptor и находит UAC2 интерфейсы
// configDescriptor — полный буфер дескрипторов конфигурации
// length — длина буфера
// Возвращает информацию об устройстве, или пустую структуру если UAC не найден
UacDeviceInfo parseUacDescriptors(const uint8_t* configDescriptor, size_t length);

// Выбирает наилучшую альт-настройку для заданных параметров
// Возвращает индекс в altSettings, или -1 если ничего не подошло
int selectBestAltSetting(
        const UacDeviceInfo& info,
        uint32_t desiredSampleRate,
        uint8_t desiredBitDepth,
        uint8_t desiredChannels);

} // namespace usbaudio
